function func() {
  // body...
  let number = document.getElementById('number').value;
  let pass = document.getElementById("passwordd").value;
  
  if (number == '09106707090' && pass == "pogiako") {
    alert("succes")
    window.location.href = "";
    
  }else if(number == '12345678' && pass == '12345678'){
    alert("succes")
    window.location.href = "";
    
  }else{
    alert("invalid")
  }
}


